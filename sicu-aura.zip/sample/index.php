<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
    integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p"
    crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"
    integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF"
    crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
  <link rel="stylesheet" href="css/style.css">
  <title>Management</title>
</head>

<body>
  <section>
    <div class="imgbx">
      <img src="image.png">
      <img class="logo" src="image-2.png">
      <div class="para">
        <p> Feel <span>safe</span> EveryWhere</p>
        <p class="graph">#safe-<span>T</span>-Fast</p>
      </div>
    </div>
    <div class="contentBx">
       
        <h2>SignUp/Login</h2>
        <?php



include("db.php");
if(isset($_POST['submit']))
{
$fname=$_POST['fname'];
$email=$_POST['email'];
$address=$_POST['address'];
$phonenumber=$_POST['phonenumber'];
$city=$_POST['city'];
$hospital=$_POST['hospital'];
$state=$_POST['state'];
$ward=$_POST['ward'];
$upload=$_POST['upload'];
$register=$_POST['register'];
$ambulance=$_POST['ambulance'];
$password=$_POST['password'];
$doctor=$_POST['doctor'];
$confirmpassword=$_POST['confirmpassword'];
$verify_query=mysqli_query($con,"SELECT email FROM registration WHERE email='$email' ");
if(mysqli_num_rows($verify_query)>0)
{
echo "<script type='text/javascript'>alert('This Email is used,Try another one please!');</script>";

}
else{
mysqli_query($con,"INSERT INTO registration(fname,email,address,phonenumber,city,hospital,state,ward,upload,register,ambulance,password,doctor,confirmpassword)values('$fname','$email','$address','$phonenumber','$city','$hospital','$state','$ward','$upload','$register','$ambulance','$password','$doctor','$confirmpassword')") or die("Error Occured");
echo "<script type='text/javascript'>alert('Registration Successfully');</script>";

}
}
?>

       
        <form action="db.php" method="post">
          
          <div class="row">
          
          <div class="col-sm-5 form-group">
          <!-- <label for="name-f">Hospital Name</label> -->
          <input type="text" class="form-control" name="fname" id="name-f" placeholder="Hospital Name." required>
          </div>
          <div class="col-sm-7 form-group">
          <!-- <label for="name-l">Email ID</label> -->
          <input type="email" class="form-control" name="email" id="name-l" placeholder="Email ID." required>
          </div>
           
               
           </div>
           <div class="row">
            <div class="col-sm-5 form-group">
            <!-- <label for="address">Address</label> -->
            <input type="text" class="form-control" name="address" id="address" placeholder="Address." required>
            </div>
            <div class="col-sm-7 form-group">
            <!-- <label for="Phonenumber">Phone Number</label> -->
            <input type="text" class="form-control" name="phonenumber" id="phonenumber" placeholder="Phone Number." required>
            </div>
             
                 
             </div>
             <div class="row">
              <div class="col-sm-5 form-group">
              <!-- <label for="city">City</label> -->
              <input type="text" class="form-control" name="city" id="city" placeholder="City" required>
              </div>
              <div class="col-sm-7 form-group">
              <!-- <label for="HRN">Hospital Registration Number</label> -->
              <input type="text" class="form-control" name="hospital" id="HRN" placeholder="Hospital Registration Number." required>
              </div>
           </div>
           <div class="row">
            <div class="col-sm-5 form-group">
            <!-- <label for="state">State</label> -->
            <input type="text" class="form-control" name="state" id="state" placeholder="State." required>
            </div>
            <div class="col-sm-7 form-group">
            <!-- <label for="EWN">Emergency Ward Number</label> -->
            <input type="text" class="form-control" name="ward" id="ward" placeholder="Emergency Ward Number." required>
            </div>
             
                 
             </div>
             <div class="row">
              <div class="col-sm-5 form-group">
              <!-- <label for="pincode">Pincode</label> -->
              <input type="text" class="form-control" name="pincode" id="pincode" placeholder="Pincode" required>
              </div>
              <div class="col-sm-7 form-group">
              <!-- <label for="RCU">Registration Certificate Upload</label> -->
              <input type="text" class="form-control" name="upload" id="upload" placeholder="Registration Certificate Upload." required>
              </div>
               
                   
               </div>
               <div class="row">
                <div class="col-sm-5 form-group">
            
                <input type="text" class="form-control" name="register" id="register" placeholder="Hospital Registration Date" required>
                </div>
                <div class="col-sm-7 form-group">
                
                  <input type="file" class="btn btn-primary float-right">
                </div>
                 
                     
                 </div>
                 <div class="row">
                  <div class="col-sm-5 form-group">
                  
                  <input type="text" class="form-control" name="ambulance" id="ambulance" placeholder="Number Of Ambulance Available" required>
                  </div>
                  <div class="col-sm-7 form-group">
                    
                    <input type="password" class="form-control" name="password" id="password" placeholder="Create Password" required>
                    </div>
                   
                       
                   </div>
                   <div class="row">
                     <div class="col-sm-5 form-group">
                    
                    <input type="text" class="form-control" name="doctor" id="doctor" placeholder="Number Of Doctors" required>
                    </div> 
                    <div class="col-sm-7 form-group">
                      
                      <input type="password" class="form-control" name="confirmpassword" id="confirmpassword" placeholder="Confirm Password" required>
                      </div>
                     
                         
                     </div>
                 <div class="btn">
                  <button class="btn btn-primary float-right">SignUp</button>
                 </div>

          </form>
    </div>

  </section>
</body>

</html>