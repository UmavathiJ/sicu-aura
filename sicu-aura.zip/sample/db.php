<?php
$con=mysqli_connect("localhost","root","","registration") or die("couldn't connect");



?>
