 const webcamElement=document.getElementById("#video");
 const canvasElement=document.getElementById("#canvas");
 const webCam=new webCam(webcamElement,"user",canvasElement);
 webCam.start();
 

