<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/login.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
    integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p"
    crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"
    integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF"
    crossorigin="anonymous"></script>
    <title>Login</title>
</head>
<body>
   <section>
    <div class="container">
       
            <div class="col-sm-6">
               <img src="image.png"  alt="...">
               <img class="pic" src="image-2.png">
               <h4>Feel <span>Safe</span> EveryWhere</h4>
               <p>#safe-<span>T</span>-Fast</p>
               <h2 class="sig">SignUp/Login</h2>
               <h5 class="sicu">Welcome to Sicu-Aura</h5>
            </div>
           <!-- <div class="col-lg-5">  -->
           <?php
          include('db.php');
          if(isset($_POST['submit']))
          {
          $hospitalname=$_POST['hospitalname'];
           $email=$_POST['email'];
           $password=$_POST['password'];
           $specialaccesscode=$_POST['specialaccesscode'];
           $verify_query=mysqli_query($con,"SELECT  FROM registration WHERE email='$email' and password=$password' ");
           $result=mysqli_query($con,$verify_query);
           $row=mysqli_fetch_array($result,MYSQLI_ASSOC);
           $count=mysqli_num_rows($result);
           if($count==1) {
            header("Location:table.php");
           }
           else{
            echo "<script type='text/javascript'>alert('Logon failed');</script>";

           }
            

           
           
        }
          ?>
           
            <form action="table.php" method="post">
               
                <div class="form-row">
                   
                    <div class="col-lg-5">
                        <input type="text" name="hospitalname" id="hospitalname" class="form-control" placeholder="Hospital Name">
                    </div>
                </div>
                <div class="form-row">
                    <div class="col-lg-5">
                        <input type="text" name="email" id="email" class="form-control"  placeholder="Email ID">
                    </div>
                </div>
                <div class="form-row">
                    <div class="col-lg-5">
                        <input type="password"name="password" id="password" class="form-control" placeholder="password">
                    </div>
                </div>
                <div class="form-row">
                    <div class="col-lg-5">
                        <input type="text" name="specialaccesscode" id="specialaccesscode" class="form-control" placeholder="Special Access Code">
                    </div>
                </div>
                <div class="form-row">
                    <div class="col-lg-5">
                        <button type="button" class="btn btn-primary">Login</button>
                    </div>
                </div>
            </form>
        </div>
        
    
   </section>
</body>

</html>