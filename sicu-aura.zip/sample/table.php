<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/table.css">
    <title>Table Format</title>
</head>
<body>
 <div class="container">
    <nav>
    <div class="logo">
        <img src="sicu-aura_logo-removebg 4.png">
    </div>
    <div class="sig">
        <img src="image-2.png">
    </div>
  <div class="btn-logout">
    <button type="button" class="btn">Logout</button>
</div>
    <div class="elise">
        <img src="Ellipse 40.png">
        <h5 class="Alex">Alex Robinson</h5>
    </div>
       <div class="develop">
            <img src="image 18.png">
        </div>
    <!-- <div class="search">
        <input type="text" class="search-btn" placeholder="search.....">
        <img src="fe_search.png">
    </div> -->
    <form>
        <input type="search" placeholder="Search...">
        <button type="submit">Search</button>
      </form>
    <h1 class="heading">Hospital Registration</h1>
    <div class="mode">
        <table>
            <tr>
             <th>No</th>
             <th>Date&Time</th>
             <th>Hospital Name</th>
             <th>Email</th>
             <th>Address</th>
             <th>Phone No</th>
             <th>City</th>
             <th>State</th>
             <th>PinCode</th>
             
         </tr>
         <tr>
            <td>1</td>
            <td>23.10.2012 & 12:00:00</td>
            <td>GH</td>
            <td>uma@gmail.com</td>
            <td>gjf</td>
            <td>6890893456</td>
            <td>chennai</td>
            <td>Tamilnadu</td>
            <td>627659</td>

          </tr>
          <tr>
            <td>2</td>
            <td>23.10.2011S &1:00:00</td>
            <td>GH</td>
            <td>uma@gmail.com</td>
            <td>gjf</td>
            <td>6890893456</td>
            <td>chennai</td>
            <td>Tamilnadu</td>
            <td>627659</td>

          </tr>
          <tr>
            <td>3</td>
            <td>23.10.2010 & 2:30:00</td>
            <td>GH</td>
            <td>uma@gmail.com</td>
            <td>gjf</td>
            <td>6890893456</td>
            <td>chennai</td>
            <td>Tamilnadu</td>
            <td>627659</td>

          </tr>
          <tr>
            <td>4</td>
            <td>23.10.2011 & 3:30:00</td>
            <td>GH</td>
            <td>uma@gmail.com</td>
            <td>gjf</td>
            <td>6890893456</td>
            <td>chennai</td>
            <td>Tamilnadu</td>
            <td>627659</td>

          </tr>
          
          
         <table>
        </div>
    
</nav>  

</div>
</body>
</html>