<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/table.css">
    <title>Table Format</title>
</head>
<body>
 <div class="container">
    <nav>
    <div class="logo">
        <img src="sicu-aura_logo-removebg 4.png">
    </div>
    <div class="sig">
        <img src="image-2.png">
    </div>
  <div class="btn-logout">
    <button type="button" class="btn">Logout</button>
</div>
    <div class="elise">
        <img src="Ellipse 40.png">
        <h5 class="Alex">Alex Robinson</h5>
    </div>
       <div class="develop">
            <img src="image 18.png">
        </div>
    <!-- <div class="search">
        <input type="text" class="search-btn" placeholder="search.....">
        <img src="fe_search.png">
    </div> -->
    <form>
        <input type="search" placeholder="Search...">
        <button type="submit">Search</button>
      </form>
    <h1 class="heading">Hospital Registration</h1>
    <div class="mode">
        <table>
            <tr>
             <th>Hospital Registration Date</th>
             <th>Hospital Registration Number</th>
             <th>Hospital Registration Photo</th>
             <th>Emergency Ward Number</th>
             <th>Number of Ambulance</th>
             <th>Number of Doctors</th>
             
         </tr>
         <tr>
            <td>21.2.2000</td>
            <td>2435678</td>
            <td><a href="">file</a></td>
            <td>2678909</td>
            <td>50</td>
            <td>68</td>
            

          </tr>
          <tr>
            <td>21.2.2000</td>
            <td>2435678</td>
            <td><a href="">file</a></td>
            <td>2678909</td>
            <td>50</td>
            <td>68</td>
            

          </tr>
          <tr>
            <td>21.2.2000</td>
            <td>2435678</td>
            <td><a href="">file</a></td>
            <td>2678909</td>
            <td>50</td>
            <td>68</td>
            

          </tr>
          <tr>
            <td>21.2.2000</td>
            <td>2435678</td>
            <td><a href="">file</a></td>
            <td>2678909</td>
            <td>50</td>
            <td>68</td>
            

          </tr>
         
            

          
           

          
          
          
         <table>
        </div>
    
</nav>  

</div>
</body>
</html>